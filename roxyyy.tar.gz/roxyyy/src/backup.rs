use crate::config::{BackupKind, Config};
use crate::services::waitfor_up;
use crate::{hwinfo, list_files, run_command, services};
use anyhow::{anyhow, Context, Result};
use chrono::Local;
use flate2::{read::GzDecoder, write::GzEncoder, Compression};
use openssl::symm::{Cipher, Crypter, Mode};
use serde::{Deserialize, Serialize};
use ssh2::Session;
use std::collections::HashMap;
use std::fs::{self, File, Metadata};
use std::io::{self, BufRead, BufReader, BufWriter, Read, Write};
use std::net::{SocketAddr, TcpStream};
use std::os::unix::fs::MetadataExt;
use std::path::Path;
use std::time::Duration;
use std::{cmp, fmt, thread};

// This version statement will be used for the Key and IV value to en/decrypt
const VERSION: &str = "AICE security";
const AICE_RAW_DB: &str = "raw.db";
const META_FILE: &str = ".meta";

/*
* Backup related files, utilities, path
  * path
    * /data/backup, /data/backup/{Data,Os}
    * /tmp, /tmp/{Data,Os}
    * REview db path
    * Postgres db path
  * utilities
    * chmod
    * cp
    * docker
    * mkdir
    * mv
    * pg_ctl, pg_dump, pg_restore

*/

#[derive(Serialize, Deserialize)]
struct SmallMetadata {
    path: String,
    mode: u32,
    uid: u32,
    gid: u32,
}

impl fmt::Display for SmallMetadata {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(
            f,
            "{:#o} {} {} {}",
            self.mode, self.uid, self.gid, self.path
        )
    }
}

/// # Errors
/// * fail to copy backup target dir and files
/// * fail to remove the copied dir and files
/// * fail to create new backup file
/// * fail to get lastname from the backup target path
pub fn new(cfg: &config::Config, kind: BackupKind) -> Result<()> {
    if kind == BackupKind::All || kind == BackupKind::Data {
        new_data_backup(cfg, BackupKind::Data)?;
    }
    if kind == BackupKind::All || kind == BackupKind::Os {
        new_os_backup(cfg, BackupKind::Os)?;
    }
    Ok(())
}

fn new_data_backup(cfg: &config::Config, kind: BackupKind) -> Result<(), anyhow::Error> {
    cfg.create_backup_path()?;

    if !Path::new(&cfg.data_backup.review_db).exists()
        && !Path::new(&cfg.data_backup.postgres_db).exists()
    {
        return Err(anyhow!("No database found."));
    }

    print!("Begin DATA backup ... ");

    // mkdir temporary folder
    let now = Local::now().format("%Y%m%d%H%M%S").to_string();
    let tmpdir = format!("/tmp/{}", now);
    fs::create_dir(&tmpdir)?;

    // backup review db
    if Path::new(&cfg.data_backup.review_db).exists() {
        let review_db_temp = format!("{}/{}", tmpdir, cfg.review_db_dir()?);
        // TODO: should stop review before backup
        copy_dir_all(&cfg.data_backup.review_db, &review_db_temp)?;
        // TODO: should start review after backup
    } else {
        println!("NoSql database not found.");
    }

    // TODO: Choose binary or docker postgres automatically
    // backup postgres db
    if Path::new(&cfg.data_backup.postgres_db).exists() {
        let dump = format!("{}/{}", tmpdir, DEFAULT_POSTGRES_DUMP_FILE);

        // if binary postgres is running ...
        // if let Err(e) = postgres_dump(cfg, &dump) {
        //     remove_tmpdir_all(cfg, &tmpdir)?;
        //     return Err(e);
        // }

        // if docker postgres is running ...
        if let Err(e) = postgres_dump_docker(cfg, &dump) {
            remove_tmpdir_all(cfg, &tmpdir)?;
            return Err(e);
        }
    } else {
        println!("Relational database not found.");
    }

    // make new backup file in /data/backup/data folder: tar+gzip+encrypt
    let plain = format!("/tmp/{}.bck", now);
    if let Err(e) = tar_gz(&tmpdir, &plain, kind) {
        remove_tmpdir_all(cfg, &tmpdir)?;
        return Err(e);
    }

    let crypted = cfg.new_backupfile(&now, kind);
    if let Err(e) = encrypt(&plain, &crypted) {
        let _r = fs::remove_file(&plain);
        remove_tmpdir_all(cfg, &tmpdir)?;
        return Err(e);
    }

    // remove temporary files in /tmp
    fs::remove_file(&plain)?;
    remove_tmpdir_all(cfg, &tmpdir)?;
    println!("Done");
    Ok(())
}

/// tar and gzip files
/// # Errors
/// * fail to create backup file in backup path
/// * fail to save the files in tmp foler into backup file
/// * fail to finish for the tar and gzipped backup file
fn tar_gz(from: &str, to: &str, kind: BackupKind) -> Result<(), anyhow::Error> {
    let tgz = match File::create(to) {
        Ok(ret) => ret,
        Err(e) => return Err(anyhow!("failed to create new backup file. {}", e)),
    };
    let encoder = GzEncoder::new(tgz, Compression::default());
    let mut tar = tar::Builder::new(encoder);
    tar.append_dir_all(&kind.to_string(), from)
        .with_context(|| anyhow!("failed to write data into backup file."))?;
    tar.finish()
        .with_context(|| anyhow!("failed to finish backup."))?;
    Ok(())
}

/// unzip and untar backup file
/// # Errors
/// * fail to open tar.gz file
/// * fail to untar or unzip
fn untar_unzip(from: &str, to: &str) -> Result<(), anyhow::Error> {
    let tgz = File::open(from)?;
    let decoder = GzDecoder::new(tgz);
    let mut archive = tar::Archive::new(decoder);
    archive.unpack(to)?;
    Ok(())
}

/// Backup OS configurations
/// # Errors
/// * backup target configuration are not exist
/// * fail to create temporary folder
/// * fail to copy files to temporary folder
/// * fail to serialize meta file
/// * fail to tar and gzip files in temporary folder
/// * fail to remove files in temporary folder
fn new_os_backup(cfg: &config::Config, kind: BackupKind) -> Result<()> {
    cfg.create_backup_path()?;

    if cfg.os_backup.targets.is_empty() {
        return Err(anyhow!("Backup target files are not configured."));
    }

    print!("Begin OS backup ... ");

    // mkdir temporary folder
    let now = Local::now().format("%Y%m%d%H%M%S").to_string();
    let tmpdir = format!("/tmp/{}", now);
    fs::create_dir(&tmpdir)?;

    // TODO: be careful the files with same name in different folder
    //   => save backup target files with it's full path
    let metadatas = backup_files_from(&tmpdir, &cfg.os_backup.targets)?;
    fs::write(
        &format!("{}/{}", tmpdir, META_FILE),
        bincode::serialize(&metadatas)?,
    )?;

    // make new os backup file in /data/backup/os
    let plain = format!("/tmp/{}.bck", now);
    if let Err(e) = tar_gz(&tmpdir, &plain, kind) {
        remove_tmpdir_all(cfg, &tmpdir)?;
        return Err(e);
    }

    let crypted = cfg.new_backupfile(&now, kind);
    if let Err(e) = encrypt(&plain, &crypted) {
        let _r = fs::remove_file(&plain);
        remove_tmpdir_all(cfg, &tmpdir)?;
        return Err(e);
    }

    // remove temporary dir and files: /tmp/xxxxx.tgz, /tmp/os
    fs::remove_file(&plain)?;
    remove_tmpdir_all(cfg, &tmpdir)?;
    println!("Done");
    Ok(())
}

// TODO: same filename
/// copy backup target files to tempoary folder
/// # Errors
/// * fail to get metadata of target file
/// * fail to create folder
/// * fail to get file names in target folder
fn backup_files_from(tmpdir: &str, targets: &[String]) -> Result<HashMap<String, SmallMetadata>> {
    let mut metadatas: HashMap<String, SmallMetadata> = HashMap::new();
    for from in targets {
        let from_path = Path::new(from);
        if !from_path.exists() {
            eprintln!("target \"{}\" not found!", from);
            log::error!("target \"{}\" not found!", from);
            continue;
        }
        let from_meta = from_path.metadata()?;
        if let Some(filename) = from_path.file_name() {
            let filename = filename.to_string_lossy().to_string();
            let to = format!("{}/{}", tmpdir, filename);
            if from_path.is_dir() {
                fs::create_dir(&to)?;
                let files = list_files(from, None, true)?;
                let files = files
                    .into_iter()
                    .map(|(_, _, f)| format!("{}/{}", from, f))
                    .collect::<Vec<_>>();
                let metas = backup_files_from(&to, &files)?;
                metadatas.extend(metas);
            // } else if from_path.is_file() { // symlink, ...
            } else {
                copy_from_to(from, &to)?;
            }

            // if I don't have read permission for the target file
            //   * In this case, tar and gzip can fail. Thus the mode should be changed to readable to every others.
            //   * like /etc/shadow, /etc/ufw/user.rules
            if from_meta.mode() & 0o004 == 0 {
                run_command("chmod", None, &["644", &to])?;
            }
            metadatas.insert(
                filename.to_string(),
                SmallMetadata {
                    path: from.to_string(),
                    mode: from_meta.mode() & 0o777,
                    uid: from_meta.uid(),
                    gid: from_meta.gid(),
                },
            );
        } else {
            eprintln!("failed to backup {:?}", from);
        }
    }
    Ok(metadatas)
}

/// copy file preserving it's attributes if possible
/// # Errors
/// * fail to run cp command
pub fn copy_from_to(from: &str, to: &str) -> Result<()> {
    if fs::copy(from, to).is_err() {
        run_command("cp", None, &["-p", "-f", from, to])?;
    }
    Ok(())
}

/// copy directory
/// # Errors
/// * fail to get directory entry
/// * fail to get file type of entry
/// * fail to get lastname of file path
fn copy_dir_all(from: impl AsRef<Path>, to: impl AsRef<Path>) -> Result<()> {
    fs::create_dir_all(&to)?;
    for entry in fs::read_dir(from)? {
        let entry = entry?;
        let ty = entry.file_type()?;
        if ty.is_dir() {
            copy_dir_all(entry.path(), to.as_ref().join(entry.file_name()))?;
        } else {
            fs::copy(entry.path(), to.as_ref().join(entry.file_name()))?;
        }
    }
    Ok(())
}

/// restore files from temporary to original place
/// # Errors
/// * fail to get files list from folder
/// * fail to copy file
/// * fail to create dir
/// * fail to get metadata
/// * fail to chmod or chown command
fn restore_files_to(tmp_path: &str, metadatas: &HashMap<String, SmallMetadata>) -> Result<()> {
    let files = list_files(tmp_path, None, true)?;
    for (_, _, filename) in &files {
        // only META_FILE is included in this case
        if metadatas.get(filename).is_none() {
            continue;
        }
        let from = format!("{}/{}", tmp_path, filename);
        let from_path = Path::new(&from);
        if let Some(org_meta) = metadatas.get(filename) {
            let to = org_meta.path.as_str();
            let to_path = Path::new(to);
            if from_path.is_dir() {
                if !to_path.exists() && fs::create_dir(to_path).is_err() {
                    run_command("mkdir", None, &[to])?;
                }
                restore_files_to(&from, metadatas)?;
            } else {
                if let Some(parent) = to_path.parent() {
                    let k = parent.as_os_str().to_string_lossy().to_string();
                    if !parent.exists() {
                        if fs::create_dir_all(parent).is_err() {
                            run_command("mkdir", None, &["-p", &k])?;
                        }
                        let parent_meta = parent.metadata()?;
                        if let Some(m) = metadatas.get(&k) {
                            restore_mode_owner_to(&k, &parent_meta, m)?;
                        }
                    }
                }
                copy_from_to(&from, to)?;
            }

            let to_meta = Path::new(to).metadata()?;
            restore_mode_owner_to(to, &to_meta, org_meta)?;
        }
    }
    Ok(())
}

/// Restore file or directory's attributes
/// # Errors
/// * fail to run chmod or chown command
fn restore_mode_owner_to(dest: &str, dest_meta: &Metadata, org_meta: &SmallMetadata) -> Result<()> {
    if org_meta.mode != dest_meta.mode() & 0o777 {
        run_command("chmod", None, &[&format!("{:o}", org_meta.mode), dest])?;
    }

    // don't care if this command failed
    if org_meta.uid != dest_meta.uid() || org_meta.gid != dest_meta.gid() {
        let _r = run_command(
            "chown",
            None,
            &[&format!("{}:{}", org_meta.uid, org_meta.gid), dest],
        );
    }
    Ok(())
}

/// Try to remove temporary files in /tmp
/// Because lack of user's privilage, some files can't remove like shadow, user.rules
///
/// WARNING
/// * This function is very dangerous, when if wrong path is given.
///   => See the checking "/tmp/"" path
///
/// # Errors
/// * failed to run sudo rm command
fn remove_tmpdir_all(cfg: &config::Config, path: &str) -> Result<()> {
    if (path.starts_with("/tmp/") || path.starts_with(&cfg.data_backup.postgres_db))
        && fs::remove_dir_all(path).is_err()
    {
        run_command("rm", None, &["-rf", path])?;
    }

    Ok(())
}

/// factory reset for Databases or OS
/// # Errors
///
pub fn factory_reset(cfg: &config::Config, kind: BackupKind) -> Result<()> {
    if kind == BackupKind::All || kind == BackupKind::Data {
        if let Some(init_file) = cfg.init_file(BackupKind::Data) {
            print!("Extracting init database ... ");
            restore_data(cfg, &init_file)?;
            let _r = reset_data_dirs(cfg);
            //cfg.cleanup_backup_path(BackupKind::Data)?;
        } else {
            return Err(anyhow!("Database init files are not found."));
        }
    }
    if kind == BackupKind::All || kind == BackupKind::Os {
        if let Some(init_file) = cfg.init_file(BackupKind::Os) {
            print!("Extracting init configurations ... ");
            restore_os(cfg, &init_file)?;
            let _r = reset_os_dirs(cfg);
            //cfg.cleanup_backup_path(BackupKind::Os)?;
            println!("system rebooting ...");
            let _r = hwinfo::shutdown(false, true);
        } else {
            return Err(anyhow!("OS init configurations are not found."));
        }
    }

    println!("Done");
    Ok(())
}

/// Data factoryreset. clear data
fn reset_data_dirs(cfg: &config::Config) -> Result<()> {
    cfg.cleanup_backup_path(BackupKind::Data)?;

    // check running services first then stop it all
    // stop zeek, review, hog, peek, reproduce, reconverge
    // let _r = services::stop_all();

    // check which container is active then stop it all
    // // stop postgres, kafka, zookeeper docker
    // //let _r = services::docker_stop(&cfg.data_backup.postgres_container);
    // let _r = services::docker_stop(DEFAULT_KAFKA_CONTAINER);
    // let _r = services::docker_stop(DEFAULT_ZOOKEEPER_CONTAINER);

    // // /data/logs, /data/spool, /data/kafka

    // for target in &cfg.data_backup.cleanup {
    //     if *target == "/" {
    //         //warning!!!!
    //         continue;
    //     }
    //     let path = Path::new(target);
    //     if path.is_dir() {
    //         let meta = path.metadata()?;
    //     } else {
    //         // just remove it
    //     }
    // }
    // services::start_all();
    // services::docker_start(DEFAULT_KAFKA_CONTAINER);
    // services::docker_start(DEFAULT_ZOOKEEPER_CONTAINER);

    Ok(())
}

/// OS factoryreset. clear log
/// * clean /data/backup/Os
/// * clean /var/log
fn reset_os_dirs(cfg: &config::Config) -> Result<()> {
    cfg.cleanup_backup_path(BackupKind::Os)?;

    // cleanup /var/syslog folder
    // * remove all files and sub-dirs in /var/log
    let files = list_files("/var/log", None, true)?;
    for (_, _, file) in files {
        let path = Path::new(&file);
        if path.is_dir() {
            run_command("rm", None, &["-rf", &file])?;
        } else {
            run_command("rm", None, &["-f", &file])?;
        }
    }
    Ok(())
}

/// # Errors
/// * backupfile and remote file name should have prefix "os" or "data"
/// * failed to authenticate
/// * invalid ssh uri format
/// * failed to create new ssh session
/// * failed to handshake ssh session
/// * failed to copy or read remote file
/// * ...
pub fn pull(cfg: &config::Config, param: &str) -> Result<()> {
    let (username, addr, remotepath) = parse_ssh_uri(param)?;
    let backupfile = if let Some(name) = Path::new(remotepath).file_name() {
        name.to_string_lossy().to_string()
    } else {
        return Err(anyhow!("invalid file name. {}", remotepath));
    };
    let path = if let Some(ret) = cfg.backupfile_path(&backupfile) {
        ret
    } else {
        return Err(anyhow!("invalid filename format!"));
    };
    let password = get_password("password: ")?;

    let tcp = TcpStream::connect(addr)?;
    let mut sess = Session::new()?;
    sess.set_tcp_stream(tcp);
    sess.handshake()?;
    sess.userauth_password(username, &password)?;

    let local_path = File::create(&path)?;
    let mut writer = BufWriter::new(local_path);

    let (mut remote_file, stat) = sess.scp_recv(Path::new(remotepath))?;
    print!("Receiving {:?} {} bytes ... ", backupfile, stat.size());
    io::copy(&mut remote_file, &mut writer)?;

    // Close the channel and wait for the whole content to be tranferred
    remote_file.send_eof()?;
    remote_file.wait_eof()?;
    remote_file.close()?;
    remote_file.wait_close()?;
    println!("Done");
    Ok(())
}

/// # Errors
/// * file not found
/// * invalid remote addr or path
/// * fail to get password
/// * fail to connect remote addr
/// * fail to send file
pub fn push(cfg: &config::Config, param: &str) -> Result<()> {
    let s_param = param.split(' ').collect::<Vec<_>>();
    let (localpath, username, addr, remotepath) = if let Some(filename) = s_param.get(0) {
        if let Some(local) = cfg.backupfile_path(filename) {
            if !Path::new(&local).exists() {
                return Err(anyhow!("backup file not found. {}", filename));
            }
            if let Some(second) = s_param.get(1) {
                let (user, remoteaddr, path) = parse_ssh_uri(*second)?;
                let remotepath = if path.ends_with('/') {
                    format!("{}{}", path, filename)
                } else {
                    format!("{}/{}", path, filename)
                };
                (local, user, remoteaddr, remotepath)
            } else {
                return Err(anyhow!("invalid parameter."));
            }
        } else {
            return Err(anyhow!("invalid filename format!"));
        }
    } else {
        return Err(anyhow!("invalid parameter."));
    };

    let password = get_password("password: ")?;

    let tcp = TcpStream::connect(addr)?;
    let mut sess = Session::new()?;
    sess.set_tcp_stream(tcp);
    sess.handshake()?;
    sess.userauth_password(username, &password)?;

    let mut local_file = File::open(&localpath)?;
    let size = local_file.metadata()?.len();
    let mut remote_file = sess.scp_send(Path::new(&remotepath), 0o644, size, None)?;

    print!("Sending {} {} bytes ... ", localpath, size);
    io::copy(&mut local_file, &mut remote_file)?;
    remote_file.flush()?;

    // Close the channel and wait for the whole content to be tranferred
    remote_file.send_eof()?;
    remote_file.wait_eof()?;
    remote_file.close()?;
    remote_file.wait_close()?;
    println!("Done");
    Ok(())
}

const DEFAULT_SSH_PORT: usize = 22;
/// Parse SSH Uri Protocol: user@host[:port]<path>
/// # Errors
/// * invalid user id, remote address or port
fn parse_ssh_uri(uri: &str) -> Result<(&str, SocketAddr, &str)> {
    if let Some(pos) = uri.find('/') {
        let path = &uri[pos..];
        let uhp = uri[..pos].split('@').collect::<Vec<_>>();
        let user_id = if let Some(first) = uhp.get(0) {
            *first
        } else {
            return Err(anyhow!("user id is required."));
        };
        if let Some(second) = uhp.get(1) {
            let remoteaddr = if second.contains(':') {
                if second.ends_with(':') {
                    let temp = format!("{}{}", second, DEFAULT_SSH_PORT);
                    temp.parse::<SocketAddr>()?
                } else {
                    second.parse::<SocketAddr>()?
                }
            } else {
                let temp = format!("{}:{}", second, DEFAULT_SSH_PORT);
                temp.parse::<SocketAddr>()?
            };
            return Ok((user_id, remoteaddr, path));
        }
    }

    Err(anyhow!("invalid ssh remote address."))
}

// TODO: merge this code to docker postgres case
/// # Errors
/// * dump command not found
/// * fail to dump
#[allow(dead_code)]
fn postgres_dump(cfg: &config::Config, output: &str) -> Result<()> {
    let (host, port) = cfg.postgres_addr()?;
    let args = vec![
        "-h",
        host,
        "-p",
        port,
        "-U",
        &cfg.data_backup.postgres_db_user,
        "-d",
        &cfg.data_backup.postgres_db_name,
        "-Fc",
        "-f",
        output,
    ];
    run_command("pg_dump", Some(&[&cfg.data_backup.bin_path]), &args)
}

/// # Errors
/// * dump command not found
/// * fail to dump
#[allow(dead_code)]
fn postgres_dump_docker(cfg: &config::Config, to: &str) -> Result<()> {
    let dump_file = format!("/tmp/{}", DEFAULT_POSTGRES_DUMP_FILE);
    let args = vec![
        "exec",
        "-i",
        &cfg.data_backup.postgres_container,
        "/bin/rm",
        "-f",
        &dump_file,
    ];
    run_command("docker", None, &args)
        .with_context(|| anyhow!("failed to remove old dump file."))?;

    let (host, port) = cfg.postgres_addr()?;
    let args = vec![
        "exec",
        "-i",
        &cfg.data_backup.postgres_container,
        "pg_dump",
        "-w",
        "-h",
        host,
        "-p",
        port,
        "-U",
        &cfg.data_backup.postgres_db_user,
        "-d",
        &cfg.data_backup.postgres_db_name,
        "-Fc",
        "-f",
        &dump_file,
    ];

    // Issue: without .pgpass file in user's home directory
    // pg_dump and pg_restore commands require to enter password always.
    run_command("docker", None, &args)
        .with_context(|| anyhow!("failed to make backup for relational database."))?;

    let from = format!("{}:{}", cfg.data_backup.postgres_container, dump_file);
    run_command("docker", None, &["cp", &from, to])
        .with_context(|| anyhow!("failed to copy dump file."))?;

    Ok(())
}

// TODO: merge this code to docker postgres case
/// # Errors
/// * restore command not found
/// * fail to restore
#[allow(dead_code)]
fn postgres_restore(cfg: &config::Config, dump: &str) -> Result<()> {
    // stop postgres
    let args = vec![cfg.data_backup.postgres_db.as_str(), "stop"];
    run_command("pg_ctl", Some(&[&cfg.data_backup.bin_path]), &args)?;
    thread::sleep(Duration::from_secs(3));

    // remove database
    // remove_temp_dir_all(cfg, &cfg.data_backup.postgres_db)?;
    remove_tmpdir_all(cfg, &format!("/tmp/{}", cfg.data_backup.postgres_db))?;
    if let Err(e) = run_command(
        "mv",
        None,
        &["-f", cfg.data_backup.postgres_db.as_str(), "/tmp"],
    ) {
        // start postgres
        run_command(
            "pg_ctl",
            Some(&[cfg.data_backup.bin_path.as_str()]),
            &[cfg.data_backup.postgres_db.as_str(), "start"],
        )?;
        return Err(anyhow!("fail to backup database. {:?}", e));
    }

    // start postgres
    run_command(
        "pg_ctl",
        Some(&[cfg.data_backup.bin_path.as_str()]),
        &[cfg.data_backup.postgres_db.as_str(), "start"],
    )?;

    // wait until postgres is up
    let (host, port) = cfg.postgres_addr()?;
    waitfor_up(host, port, 4)?;

    // restore database
    let args = vec![
        "-h",
        host,
        "-p",
        port,
        "-U",
        &cfg.data_backup.postgres_db_user,
        "-d",
        &cfg.data_backup.postgres_db_name,
        dump,
    ];
    run_command("pg_restore", Some(&[&cfg.data_backup.bin_path]), &args)
}

/// # Errors
/// * restore command not found
/// * fail to restore
fn postgres_restore_docker(cfg: &config::Config, dump: &str) -> Result<()> {
    // stop docker postgres
    print!("Stop relational dbms ... ");
    if services::docker_stop(&cfg.data_backup.postgres_container).is_err() {
        return Err(anyhow!("failed to stop relational dbms"));
    }
    thread::sleep(Duration::from_secs(4));
    println!("done");

    // remove current database. (Just move to /tmp folder)
    print!("Remove old database ... ");
    remove_tmpdir_all(cfg, &format!("/tmp/{}", cfg.postgres_db_dir()?))?;
    if let Err(e) = run_command(
        "mv",
        None,
        &["-f", cfg.data_backup.postgres_db.as_str(), "/tmp"],
    ) {
        // if fail, start postgres and return
        let _r = services::docker_start(&cfg.data_backup.postgres_container);
        return Err(anyhow!("fail to remove old database. {:?}", e));
    }
    println!("done");

    // start postgres
    print!("Start relational dbms ... ");
    if services::docker_start(&cfg.data_backup.postgres_container).is_err() {
        return Err(anyhow!("fail to start relational dbms"));
    }

    // check postgres is up
    let (host, port) = cfg.postgres_addr()?;
    waitfor_up(host, port, 4)?;
    thread::sleep(Duration::from_secs(3));
    println!("done");

    let dump_in_docker = format!("/tmp/{}", DEFAULT_POSTGRES_DUMP_FILE);
    let to = format!("{}:{}", cfg.data_backup.postgres_container, dump_in_docker);

    // copy backup file into postgres docker container
    run_command("docker", None, &["cp", dump, &to])?;

    // restore dump file
    let args = vec![
        "exec",
        "-i",
        &cfg.data_backup.postgres_container,
        "pg_restore",
        "-h",
        host,
        "-p",
        port,
        "-U",
        &cfg.data_backup.postgres_db_user,
        "-d",
        &cfg.data_backup.postgres_db_name,
        &dump_in_docker,
    ];

    print!("Restoring database ... ");
    // issue: not to enter password the .pgpass file is required in user's home dir.
    run_command("docker", None, &args)?;
    println!("done");

    Ok(())
}

fn review_db_restore(cfg: &config::Config, from: &str) -> Result<()> {
    // stop review
    print!("Stop REview service ... ");
    services::stop("review")?;
    thread::sleep(Duration::from_secs(3));
    println!("done");

    // remove old database. Just move to /tmp folder
    print!("Remove old NoSql database ... ");
    remove_tmpdir_all(cfg, &format!("/tmp/{}", cfg.review_db_dir()?))?;
    //remove_tmpdir_all(cfg, &format!("{}/") cfg.data_backup.review_db)?;
    if let Err(e) = run_command(
        "mv",
        None,
        &["-f", cfg.data_backup.review_db.as_str(), "/tmp"],
    ) {
        // if fail, start review and return
        services::start("review")?;
        return Err(anyhow!("fail to remove old NoSql database. {:?}", e));
    }
    println!("done");

    // restore database
    print!("Restore NoSql database ... ");
    copy_dir_all(from, &cfg.data_backup.review_db)?;
    println!("done");

    // start review
    print!("Start REview service ... ");
    services::start("review")?;
    println!("done");

    Ok(())
}

/// get backup files
/// # Errors
/// * fail to read directory and it's metadata
pub fn listup(cfg: &config::Config) -> Result<()> {
    cfg.create_backup_path()?;

    let data_backup_path = format!("{}/{}", cfg.backup_path, BackupKind::Data);
    let files = list_files(&data_backup_path, None, false)?;
    if files.is_empty() {
        println!("No Data backups found.");
    } else {
        println!("Data backups:");
        print_list(&files);
    }

    let os_backup_path = format!("{}/{}", cfg.backup_path, BackupKind::Os);
    let files = list_files(&os_backup_path, None, false)?;
    if files.is_empty() {
        println!("No OS backups found.");
    } else {
        println!("OS backups:");
        print_list(&files);
    }

    Ok(())
}

/// # Errors
/// * fail to remove backup file
/// * backup file not found
pub fn remove(cfg: &config::Config, backupfile: &str) -> Result<()> {
    if let Some(path) = cfg.backupfile_path(backupfile) {
        if Path::new(&path).exists() {
            fs::remove_file(&path)?;
            println!("backup file \"{}\" removed.", backupfile);
            Ok(())
        } else {
            Err(anyhow!("backup file \"{}\" not found!", backupfile))
        }
    } else {
        Err(anyhow!("invalid backup file \"{}\"!", backupfile))
    }
}

/// # Errors
/// * fail to open the backup file
/// * fail to unpack backup file
pub fn restore(cfg: &config::Config, backupfile: &str) -> Result<()> {
    if let Some(path) = cfg.backupfile_path(backupfile) {
        if !Path::new(&path).exists() {
            return Err(anyhow!("backup file not found. {}", backupfile));
        }

        println!("Restoring from {} ... ", backupfile);

        if backupfile.starts_with(&BackupKind::Os.to_string()) {
            if cfg.os_backup.targets.is_empty() {
                return Err(anyhow!("OS init processes are not configured!"));
            }
            print!("Extracting data from {} ... ", backupfile);
            restore_os(cfg, &path)?;
        } else if backupfile.starts_with(&BackupKind::Data.to_string()) {
            if !Path::new(&cfg.data_backup.review_db).exists()
                && !Path::new(&cfg.data_backup.postgres_db).exists()
            {
                return Err(anyhow!("Running database not found!"));
            }
            print!("Extracting data from {} ... ", backupfile);
            restore_data(cfg, &path)?;
        } else {
            return Err(anyhow!("invalid backup file format."));
        }
    } else {
        return Err(anyhow!("invalid backup file format!"));
    }

    println!("Restoring completed!");
    Ok(())
}

/// # Errors
/// * fail to decrypt
/// * fail to untar or unzip
fn extract_to(from: &str, to: &str) -> Result<()> {
    if let Some(backupfile) = Path::new(from).file_name() {
        let plain = format!("/tmp/{}", backupfile.to_string_lossy());
        if decrypt(from, &plain).is_err() {
            fs::remove_file(&plain)?;
            return Err(anyhow!("fail to decrypt file"));
        }

        // extract backup file in "/tmp"
        if let Err(e) = untar_unzip(&plain, to) {
            fs::remove_file(&plain)?;
            return Err(e);
        }
    }
    Ok(())
}

/// # Errors
/// * fail to extract
fn restore_data(cfg: &config::Config, from: &str) -> Result<()> {
    // remove old /tmp/Data
    let tmp_path = format!("/tmp/{}", BackupKind::Data);
    if Path::new(&tmp_path).exists() {
        remove_tmpdir_all(cfg, &tmp_path)?;
    }

    if let Err(e) = extract_to(from, "/tmp") {
        println!("failed");
        return Err(e);
    }
    println!("done");

    // restore postgres db
    let postgres_dump = format!("{}/{}", tmp_path, DEFAULT_POSTGRES_DUMP_FILE);
    if Path::new(&postgres_dump).exists() {
        postgres_restore_docker(cfg, &postgres_dump)?;
    }

    // restore review db
    let review_db_dump = format!("{}/{}", tmp_path, cfg.review_db_dir()?);
    if Path::new(&review_db_dump).exists() {
        review_db_restore(cfg, &review_db_dump)?;
    }

    remove_tmpdir_all(cfg, &tmp_path)?;

    Ok(())
}

/// Restore OS backup file
/// # Errors
fn restore_os(cfg: &config::Config, from: &str) -> Result<()> {
    // remove old /tmp/Os
    let tmp_path = format!("/tmp/{}", BackupKind::Os);
    if Path::new(&tmp_path).exists() {
        remove_tmpdir_all(cfg, &tmp_path)?;
    }
    if let Err(e) = extract_to(from, "/tmp") {
        println!("failed");
        return Err(e);
    }
    println!("done");

    print!("Restore OS configurations ... ");

    // read metadata file
    let mut meta = File::open(&format!("{}/{}", tmp_path, META_FILE))?;
    let mut bytes = Vec::new();
    meta.read_to_end(&mut bytes)?;
    let metadatas: HashMap<String, SmallMetadata> =
        bincode::deserialize(&bytes).with_context(|| anyhow!("can't find metadata file!"))?;

    restore_files_to(&tmp_path, &metadatas)?;
    println!("done");

    println!("Restart services ... ");
    for service in &cfg.os_backup.after_services {
        let s = service.split(' ').collect::<Vec<_>>();
        if let Some(cmd) = s.get(0) {
            run_command(*cmd, None, &s[1..])?;
        }
    }

    remove_tmpdir_all(cfg, &tmp_path)?;

    Ok(())
}

/// # Errors
/// * fail to open gzip target file
/// * fail to create gzip file
/// & fail to copy target file to gzip
fn only_gzip(path: &str) -> Result<()> {
    let file = File::open(path)?;
    let mut input = BufReader::new(file);
    let output = File::create(&format!("{}.gz", path))?;
    let mut encoder = GzEncoder::new(output, Compression::default());
    io::copy(&mut input, &mut encoder)?;
    encoder.finish()?;
    Ok(())
}

fn iv_key(base: &str, keylen: usize) -> (Vec<u8>, Vec<u8>) {
    let mut key: Vec<u8> = Vec::new();
    let base = base.as_bytes();
    let mut copied = key.len();
    while copied < keylen {
        let min = cmp::min(keylen - copied, base.len());
        key.extend(base[..min].to_owned());
        copied += min;
    }
    let mut iv = key.clone();
    iv.reverse();
    (iv, key)
}

/// # Errors
/// * fail to open plain file
/// * fail to create new file for crypted
/// * fail to init encrypter
/// * fail to read plain file contents
/// * fail to encrypt
/// * fail to write crypted contents
fn encrypt(plain: &str, crypted: &str) -> Result<()> {
    let f = File::open(plain)?;
    let mut reader = BufReader::with_capacity(100_000, f);
    let block_size = Cipher::aes_128_cbc().block_size();
    let mut output = vec![0; 100_000 + block_size];

    let enc_file = File::create(crypted)?;
    let mut writer = BufWriter::new(enc_file);

    let (iv, key) = iv_key(VERSION, block_size);
    let mut encrypter = Crypter::new(Cipher::aes_128_cbc(), Mode::Encrypt, &key, Some(&iv))?;
    loop {
        let buf = reader.fill_buf()?;
        if buf.is_empty() {
            break;
        }
        let cnt = encrypter.update(buf, &mut output)?;
        writer.write_all(&output[..cnt])?;
        let read_size = buf.len();
        reader.consume(read_size);
    }

    let cnt = encrypter.finalize(&mut output)?;
    if cnt > 0 {
        writer.write_all(&output[..cnt])?;
    }
    Ok(())
}

/// # Errors
/// * fail to open crypted file
/// * fail to created new file for plain
/// * fail to init decrypter
/// * fail to decrypt
/// * fail to write decrypted contents to new file
fn decrypt(crypted: &str, plain: &str) -> Result<()> {
    let f = File::open(crypted)?;
    let mut reader = BufReader::with_capacity(100_000, f);
    let block_size = Cipher::aes_128_cbc().block_size();
    let mut output = vec![0; 100_000 + block_size];

    let dec_file = File::create(plain)?;
    let mut writer = BufWriter::new(dec_file);

    let (iv, key) = iv_key(VERSION, block_size);
    let mut decrypter = Crypter::new(Cipher::aes_128_cbc(), Mode::Decrypt, &key, Some(&iv))?;
    loop {
        let buf = reader.fill_buf()?;
        if buf.is_empty() {
            break;
        }
        let cnt = decrypter.update(buf, &mut output)?;
        writer.write_all(&output[..cnt])?;
        let read_size = buf.len();
        reader.consume(read_size);
    }

    let cnt = decrypter.finalize(&mut output)?;
    if cnt > 0 {
        writer.write_all(&output[..cnt])?;
    }
    Ok(())
}
