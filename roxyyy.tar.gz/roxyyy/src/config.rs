use crate::list_files;
use anyhow::{anyhow, Result};
use config::File;
use serde::Deserialize;
use std::{env, fmt, fs, path::Path, str::FromStr};
use users::{get_current_groupname, get_current_username};

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum BackupKind {
    Os,
    Data,
    All,
}

impl FromStr for BackupKind {
    type Err = ();

    fn from_str(input: &str) -> Result<Self, Self::Err> {
        match input.to_lowercase().as_str() {
            "os" => Ok(BackupKind::Os),
            "data" => Ok(BackupKind::Data),
            "all" => Ok(BackupKind::All),
            _ => Err(()),
        }
    }
}

impl fmt::Display for BackupKind {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{:?}", self)
    }
}

#[derive(Deserialize, Debug)]
pub struct Config {
    pub review_addr: String,
    pub backup_path: String,
    pub ethernet_prefix: String,
    pub idle_timeout: u32,
    pub version_path: String,
    pub current_username: String,
    pub current_groupname: String,

    pub os_backup: OsBackup,
    pub data_backup: DataBackup,
}

#[derive(Deserialize, Debug)]
pub struct OsBackup {
    pub targets: Vec<String>,
    pub after_services: Vec<String>,
}

#[derive(Deserialize, Debug)]
pub struct DataBackup {
    pub bin_path: String,
    pub review_db: String,
    pub postgres_db: String,
    pub postgres_addr: String,
    pub postgres_container: String,
    pub postgres_db_user: String,
    pub postgres_db_name: String,
    pub cleanup: Vec<String>,
}

// TODO: should change this path to /usr/local/aice/conf/config.toml?
const DEFAULT_CONFIG_TOML: &str = "/etc/config.toml";

const DEFAULT_REVIEW_ADDR: &str = "127.0.0.1:38390";
const DEFAULT_BACKUP_PATH: &str = "/data/backup";
const DEFAULT_ETHERNET_PREFIX: &str = "en";
const DEFAULT_VERSION_PATH: &str = "/etc/version";
const DEFAULT_USERNAME: &str = "root";

const DEFAULT_BIN_PATH_DATA: &str = "/usr/local/postgres/bin";
const DEFAULT_REVIEW_DB: &str = "/usr/local/aice/review/db";
const DEFAULT_POSTGRES_DB: &str = "/data/AICE_DB";
const DEFAULT_POSTGRES_ADDR: &str = "127.0.0.1:5432";
const DEFAULT_POSTGRES_CONTAINER: &str = "aice_db";
const DEFAULT_POSTGRES_DB_USER: &str = "postgres";
const DEFAULT_POSTGRES_DB_NAME: &str = "postgres";

pub const DEFAULT_POSTGRES_DUMP_FILE: &str = "postgres.dump";
pub const DEFAULT_ZOOKEEPER_CONTAINER: &str = "zookeeper";
pub const DEFAULT_KAFKA_CONTAINER: &str = "kafka";

impl Config {
    /// # Errors
    /// * fail to merge config.toml
    pub fn new() -> Result<Self> {
        let path = DEFAULT_CONFIG_TOML;
        let mut s = config::Config::default();

        s.set_default("review_addr", DEFAULT_REVIEW_ADDR)?;
        s.set_default("backup_path", DEFAULT_BACKUP_PATH)?;
        s.set_default("ethernet_prefix", DEFAULT_ETHERNET_PREFIX)?;
        s.set_default("version_path", DEFAULT_VERSION_PATH)?;

        match get_current_username() {
            Some(uname) => {
                s.set_default("current_username", uname.to_string_lossy().to_string())?;
            }
            None => {
                if let Ok(acc) = env::var("USER") {
                    s.set_default("current_username", acc.as_str())?;
                } else {
                    s.set_default("current_username", DEFAULT_USERNAME)?;
                }
            }
        }
        match get_current_groupname() {
            Some(gname) => {
                s.set_default("current_groupname", gname.to_string_lossy().to_string())?;
            }
            None => {
                s.set_default("current_groupname", DEFAULT_USERNAME)?;
            }
        }

        s.set_default("data_backup.bin_path", DEFAULT_BIN_PATH_DATA)?;
        s.set_default("data_backup.review_db", DEFAULT_REVIEW_DB)?;
        s.set_default("data_backup.postres_db", DEFAULT_POSTGRES_DB)?;
        s.set_default("data_backup.postgres_addr", DEFAULT_POSTGRES_ADDR)?;
        s.set_default("data_backup.postgres_container", DEFAULT_POSTGRES_CONTAINER)?;
        s.set_default("data_backup.postgres_db_user", DEFAULT_POSTGRES_DB_USER)?;
        s.set_default("data_backup.postgres_db_name", DEFAULT_POSTGRES_DB_NAME)?;

        s.merge(File::with_name(path))?;
        Ok(s.try_into()?)
    }

    /// # Errors
    /// * invalid ip address or port number
    pub fn postgres_addr(&self) -> Result<(&str, &str)> {
        let addr: Vec<_> = self.data_backup.postgres_addr.split(':').collect();
        if addr.len() == 2 {
            Ok((addr[0], addr[1]))
        } else {
            Err(anyhow!("invalid database address."))
        }
    }

    /// # Errors
    pub fn postgres_db_dir(&self) -> Result<&str> {
        Path::new(&self.data_backup.postgres_db)
            .file_name()
            .ok_or_else(|| anyhow!("invalid db_path."))?
            .to_str()
            .ok_or_else(|| anyhow!("invalid db_path."))
    }

    /// get "db" from "/usr/local/aice/review/db"
    /// # Errors
    pub fn review_db_dir(&self) -> Result<&str> {
        Path::new(&self.data_backup.review_db)
            .file_name()
            .ok_or_else(|| anyhow!("invalid db_path."))?
            .to_str()
            .ok_or_else(|| anyhow!("invalid db_path."))
    }

    //TODO: how to check the file is valid backup file?
    /// Make new backup file name in format of "/<backup-path>/<backup-kind>/<backup-kind>_<now>.bck"
    #[must_use]
    pub fn new_backupfile(&self, now: &str, kind: BackupKind) -> String {
        format!("{}/{}/{}_{}.bck", self.backup_path, kind, kind, now)
    }

    /// Return backup file path.
    /// All backup files starting with 'Os' will be exist in /data/backup/Os, ...
    #[must_use]
    pub fn backupfile_path(&self, filename: &str) -> Option<String> {
        if filename.starts_with(&BackupKind::Data.to_string()) {
            Some(format!(
                "{}/{}/{}",
                self.backup_path,
                BackupKind::Data,
                filename
            ))
        } else if filename.starts_with(&BackupKind::Os.to_string()) {
            Some(format!(
                "{}/{}/{}",
                self.backup_path,
                BackupKind::Os,
                filename
            ))
        } else {
            None
        }
    }

    #[must_use]
    pub fn init_file(&self, kind: BackupKind) -> Option<String> {
        if let Ok(ret) = list_files(&self.backup_path, None, false) {
            for (_, _, filename) in ret {
                if filename.starts_with(&kind.to_string()) {
                    return Some(format!("{}/{}", self.backup_path, filename));
                }
            }
        }
        None
    }

    /// Create /data/backup and /data/backup/{Os,Data}
    /// # Errors
    /// * failed to create backup directory
    pub fn create_backup_path(&self) -> Result<()> {
        if !Path::new(&self.backup_path).exists() {
            fs::create_dir_all(&self.backup_path)?;
        }

        let data_backup_path = format!("{}/{}", self.backup_path, BackupKind::Data);
        if !Path::new(&data_backup_path).exists() {
            fs::create_dir(&data_backup_path)?;
        }

        let os_backup_path = format!("{}/{}", self.backup_path, BackupKind::Os);
        if !Path::new(&os_backup_path).exists() {
            fs::create_dir(&os_backup_path)?;
        }

        Ok(())
    }

    /// Remove directory /data/backup/{Os,Data} and it's all files under the directory
    /// # Errors
    /// * fail to remove /data/backup/Data, /data/backup/Os directory
    pub fn cleanup_backup_path(&self, kind: BackupKind) -> Result<()> {
        if kind == BackupKind::All || kind == BackupKind::Data {
            fs::remove_dir_all(&format!("{}/{}", self.backup_path, BackupKind::Data))?;
        }
        if kind == BackupKind::All || kind == BackupKind::Os {
            fs::remove_dir_all(&format!("{}/{}", self.backup_path, BackupKind::Os))?;
        }
        Ok(())
    }
}
